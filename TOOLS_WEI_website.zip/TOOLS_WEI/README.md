# TOOLS WEI ⚡

Static browser-based social content toolkit with Cyber Neon styling.

## Included
- Post Maker: title, caption, hashtags, styles, copy/share
- Poster Studio: generate and download PNG posters in-browser
- Facebook Page connection and Page publishing via Meta JavaScript SDK / Graph API
- Privacy Policy, Terms of Service, Data Deletion pages

## Deploy to GitHub Pages
1. Create or open your GitHub repository.
2. Upload all files in this folder to the repository root.
3. In GitHub, open Settings → Pages.
4. Choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site.

## Facebook setup (not automatic)
1. Create a Meta Developer app and add Facebook Login.
2. Configure the website platform, exact GitHub Pages URL/domain, OAuth redirect settings and app domains as required by Meta.
3. Add and configure the permissions required for Page listing and publishing.
4. Replace no source code: enter your Meta App ID in the Facebook Page tab, then Save and Login.
5. Request App Review / business verification if Meta requires it for the permissions and intended users.

The app cannot publish until the Meta app is correctly configured and the logged-in user has the required Page task/permissions. API permissions and review outcomes are controlled by Meta.

## Important limitations
- Facebook Group auto-publishing and automatic friend tagging are not implemented; Meta restricts these capabilities.
- This is a static browser-only build. Drafts and access tokens are not sent to a TOOLS WEI backend. Tokens are held in memory for the active page session.
- The Facebook Graph API version can be adjusted in the UI if Meta changes supported versions.
- Before public launch, verify Meta's current Platform Terms, required disclosures, App Review requirements, and policy wording. Legal pages are starter templates, not legal advice.
